tasks = []
def task_list():
    for task in tasks:
        print(task)


def options():
    print("------------------------")
    print("Options:")
    print("1. Add task")
    print("2. View tasks")
    print("3. Mark task as done")
    print("4. Delete task")
    print("5. Quit")
    print("")



#  FUNCTIONS
# add task function
def add_task():
    new_task = input("Add task: ")
    task_dict = {"task": new_task, "Done": False}
    tasks.append(task_dict)
    print("Task added")

# View tasks
def view_tasks():
    for index, task in enumerate(tasks):
        print(f"{index + 1}. {task['task']}")

# Mark Tasks

def mark_task():

    view_tasks()
    pick_task= int(input("Which task is done? "))
    tasks[pick_task-1]["Done"] = True
    print("Task is complete")

# Delete taks
def delete_task():
    view_tasks()
    pick_task = int(input("Which task do you want to delete? "))
    remove_task = pick_task - 1
    removed=tasks.pop(remove_task)
    print(f"Task deleted: {removed['task']}")


# Main loop
while True:
    options()
    choice = input("Choose an option: ")
    # For now, just stop if user types 5
    if choice == "1":
        add_task()
    if choice == "2":
        view_tasks()
    if choice == "3":
        mark_task()
    if choice == "4":
        delete_task()
    if choice == "5":
        break

