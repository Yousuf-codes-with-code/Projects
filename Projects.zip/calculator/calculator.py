from unittest import result
def add(x,y):
    return x+y
def sub(x,y):
    return x-y
def mul(x,y):
    return x*y
def div(x,y):
    if y == 0:
        print("invalid")
    return x/y

def pow(x,y):
    return x**y
def mod(x,y):
    return x%y


def calculator():
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")
    print("5. Exponentiation")
    print("6. Logarithm")
calculator()

x = int(input("Enter a number: "))
y = int(input("Enter another number: "))


result = int(input("Enter your choice (1,2,3,4,5,6): "))
if result == 1:
    print("The result is:",x, "+" , y, "=" ,add(x, y))
elif result == 2:
    print("The result is:",x, "-" , y, "=" ,sub(x, y))
elif result == 3:
    print("The result is:",x, "*" , y, "=" ,mul(x, y))
elif result == 4:
    print("The result is:",x, "/" , y, "=" ,div(x, y))
elif result == 5:
    print("The result is:",x, "^" , y, "=" ,pow(x, y))
elif result == 6:
    print("The result is:2",x, "%" , y, "=" ,mod(x, y))
if result == 7:
    print("The result is invalid")




