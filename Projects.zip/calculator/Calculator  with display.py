import tkinter as tk

from tkinter import ttk
from tkinter import *
expression =""
# window settings
window = tk.Tk()
window.title("Calculator")
window.geometry("300x450")
window.resizable(False, False)
window.configure(background="#90EE90")
# function
def button_click(value):
    # point out the global expression variable
    global expression

    # concatenation of string
    expression = expression + str(value)

    # update the expression by using set method
    equation.set(expression)

def equation_click():
    # Try and except statement is used
    # for handling the errors like zero
    # division error etc.

    # Put that code inside the try block
    # which may generate the error
    try:

        global expression

        # eval function evaluate the expression
        # and str function convert the result
        # into string
        total = str(eval(expression))

        equation.set(total)

        # initialize the expression variable
        # by empty string
        expression = ""

    # if error is generate then handle
    # by the except block
    except:

        equation.set(" error ")
        expression = ""

# Function to clear the contents
# of text entry box
def clear():
    global expression
    expression = ""
    equation.set("")

#
equation = StringVar()
expression_field = tk.Entry(window, textvariable=equation)


expression_field.place(relx=0.1, rely=0.1)

#frame
frame=tk.Frame(window)
frame.pack(pady=90)

blank = tk.Label(frame, text="", padx=15, pady=15, cursor="hand2")
blank.grid(column=0, row=0, )


button0 = tk.Button(frame, text="0", padx=15, pady=10, cursor= "hand2", command=lambda: button_click(0))
button0.grid(column=2, row=5, )
button1 = tk.Button(frame, text="1", padx=15, pady=10, cursor= "hand2", command=lambda: button_click(1))
button1.grid(column=1, row=2, )
button2 = tk.Button(frame, text="2", padx=15, pady=10, cursor= "hand2", command=lambda: button_click(2))
button2.grid(column=2, row=2, )
button3 = tk.Button(frame, text="3", padx=15, pady=10, cursor="hand2", command=lambda: button_click(3))
button3.grid(column=3, row=2, )
button4 = tk.Button(frame, text="4", padx=15, pady=10, cursor="hand2", command=lambda: button_click(4))
button4.grid(column=1, row=3, )
button5 = tk.Button(frame, text="5", padx=15, pady=10, cursor="hand2", command=lambda: button_click(5))
button5.grid(column=2, row=3, )
button6 = tk.Button(frame, text="6", padx=15, pady=10, cursor="hand2", command=lambda: button_click(6))
button6.grid(column=3, row=3, )
button7 = tk.Button(frame, text="7", padx=15, pady=10, cursor="hand2", command=lambda: button_click(7))
button7.grid(column=1, row=4, )
button8 = tk.Button(frame, text="8", padx=15, pady=10, cursor="hand2", command=lambda: button_click(8))
button8.grid(column=2, row=4, )
button9 = tk.Button(frame, text="9", padx=15, pady=10, cursor="hand2", command=lambda: button_click(9))
button9.grid(column=3, row=4, )

# opperators
buttonkomma = tk.Button(frame, text=",", padx=15, pady=10, cursor= "hand2", command=lambda: button_click(","))
buttonkomma.grid(column=3, row=5, )
buttonplus = tk.Button(frame, text="+", padx=15, pady=15, cursor="hand2", command=lambda: button_click("+"))
buttonplus.grid(column=0, row=2, )
butttonmin = tk.Button(frame, text="-", padx=15, pady=15, cursor="hand2", command=lambda: button_click("-"))
butttonmin.grid(column=0, row=3, )
buttonmult = tk.Button(frame, text="*", padx=15, pady=15, cursor="hand2", command=lambda: button_click("*"))
buttonmult.grid(column=0, row=4, )
buttondiv = tk.Button(frame, text="/", padx=15, pady=15, cursor="hand2", command=lambda: button_click("/"))
buttondiv.grid(column=0, row=5, )

buttonexp = tk.Button(frame, text="^", padx=15, pady=15, cursor="hand2", command=lambda: button_click("**"))
buttonexp.grid(column=1, row=0, )
buttonclear = tk.Button(frame, text="clear", padx=15, pady=15, cursor="hand2", command=lambda: clear())
buttonclear.grid(column=2, row=0, )
buttonequal = tk.Button(frame, text="=", padx=15, pady=15, cursor="hand2", command=lambda: equation_click(), bg="blue", fg="white")
buttonequal.grid(column=3, row=0, )






window.mainloop()
