import time
import random

operators = ["+", "-", "*"]

min_operand =0
max_operand =20
total_equations=20


def generate_equation():
    left = random.randint(min_operand, max_operand)
    right = random.randint(min_operand, max_operand)
    operator = random.choice(operators)
    expr =str(left) + operator + str(right)
    answer = eval(expr)
    return expr, answer

wrong = 0
input("press enter to start")
print("__________________________________________")

start_time = time.time()

for i in range(total_equations):
    expr, answer = generate_equation()
    while True:
        guess = input("Equation #" + str(i+1)+ ": " + expr + "=")
        if guess == str(answer):
            break


        wrong += 1
end_time = time.time()
total_time = round(end_time) - round(start_time)


print("__________________________________________")
print("well done, you took", total_time, "seconds to complete and", "you had" , wrong, "wrong answers")
