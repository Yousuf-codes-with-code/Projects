import tkinter as tk
from tkinter import simpledialog, messagebox
import json
import os

# --------- Flashcard Data Structure ---------
flashcard_sets = {}  # Example: {"Math": [{"Q": "2+2", "A": "4"}]}
current_cards = []
current_index = 0
is_showing_answer = False

# save function
import json
import os

SAVE_FILE = "flashcards.json"

def save_flashcards():
    with open(SAVE_FILE, "w") as f:
        json.dump(flashcard_sets, f)

def load_flashcards():
    global flashcard_sets
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r") as f:
            loaded = json.load(f)
        # Cleanup empty sets and empty cards
        cleaned = {}
        for set_name, cards in loaded.items():
            # Skip empty or whitespace-only set names
            if not set_name.strip():
                continue

            cleaned_cards = []
            for card in cards:
                q = card.get("Q", "").strip()
                a = card.get("A", "").strip()
                if q and a:  # only keep cards with non-empty Q & A
                    cleaned_cards.append({"Q": q, "A": a})

            if cleaned_cards:
                cleaned[set_name.strip()] = cleaned_cards

        flashcard_sets = cleaned
    else:
        flashcard_sets = {}

# Tool tip for long text
class tooltip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tipwindow = None
        self.widget.bind("<Enter>", self.show_tip)
        self.widget.bind("<Leave>", self.hide_tip)

    def show_tip(self, event=None):
        if self.tipwindow or not self.text:
            return
        x = self.widget.winfo_rootx() + 20
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 10
        self.tipwindow = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)  # Remove window decorations
        tw.wm_geometry(f"+{x}+{y}")
        label = tk.Label(tw, text=self.text, background="#ffffe0", relief="solid", borderwidth=1,
                         font=("Arial", 10))
        label.pack()

    def hide_tip(self, event=None):
        if self.tipwindow:
            self.tipwindow.destroy()
            self.tipwindow = None

# Scrolling ststem
def create_scrollable_frame(parent):
    container = tk.Frame(parent)
    canvas = tk.Canvas(container, borderwidth=0, background="#f0f0f0", highlightthickness=0)
    scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas, background="#f0f0f0")

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    container.pack(fill="both", expand=True)

    # Cross-platform mousewheel binding
    def _on_mousewheel(event):
        if event.delta:  # Windows / MacOS
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        elif event.num == 4:  # Linux scroll up
            canvas.yview_scroll(-1, "units")
        elif event.num == 5:  # Linux scroll down
            canvas.yview_scroll(1, "units")

    # Bind mousewheel when cursor is over the canvas
    canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _on_mousewheel))
    canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>"))
    # Linux scroll events
    canvas.bind("<Enter>", lambda e: canvas.bind_all("<Button-4>", _on_mousewheel))
    canvas.bind("<Enter>", lambda e: canvas.bind_all("<Button-5>", _on_mousewheel))
    canvas.bind("<Leave>", lambda e: canvas.unbind_all("<Button-4>"))
    canvas.bind("<Leave>", lambda e: canvas.unbind_all("<Button-5>"))

    canvas.yview_moveto(0)

    return scrollable_frame

# defining functions

# creating a window
window = tk.Tk()
window.title("Study Helper")
window.geometry("400x500")
window.configure(bg="#f0f0f0")  # Light gray background
window.resizable(False, False)


# functions

def show_frame(frame):
    frame.tkraise()
def update_current_set():
    global current_set, current_index
    current_set = set_var.get()
    current_index = 0

def create_set():
    new_set = new_set_entry.get().strip()
    if new_set and new_set not in flashcard_sets:
        flashcard_sets[new_set] = []
        set_dropdown["menu"].add_command(label=new_set, command=tk._setit(set_var, new_set))
        set_var.set(new_set)
        new_set_entry.delete(0, tk.END)
#Pages
main_menu = tk.Frame(window, bg="#f0f0f0")
flashcard_menu = tk.Frame(window, bg="#f0f0f0")
flashcard_practice = tk.Frame(window, bg="#f0f0f0")
flashcard_list = tk.Frame(window, bg="#f0f0f0")
edit_set_frame = tk.Frame(window, bg="#f0f0f0")
edit_set_frame.place(x=0, y=0, width=400, height=500)


for frame in (main_menu, flashcard_menu,flashcard_practice, flashcard_list,  edit_set_frame):
    frame.place(x=0, y=0, width=400, height=500)

# main menu
title_label = tk.Label(window, text="Study helper", font=("Arial", 20, "bold"), bg="#f0f0f0", fg="#333333")
title_label.pack(pady=20)

menu_label = tk.Label(main_menu, text="📘 What do you want to do?", font=("Arial",14), bg="#f0f0f0")
menu_label.pack(pady=14)

    # buttons
button_style = {"font": ("Arial", 12), "width": 25, "height": 2, "bg": "#ffffff", "relief": "raised"}


# main menu page
tk.Button(main_menu, text="📃 Flashcards", command=lambda: show_frame(flashcard_menu), **button_style).pack(pady=10)
tk.Button(main_menu, text="❌ Quit", command=window.quit, **button_style).pack(pady=10)

# flash card page
flash_label= tk.Label(flashcard_menu, text="Options:", font=("Arial",14), bg="#f0f0f0")
flash_label.pack(pady=14)

tk.Button(flashcard_menu, text="📃Practice Flashcards", command=lambda: [load_flashcard_sets(), show_frame(flashcard_practice)], **button_style).pack(pady=10)
tk.Button(flashcard_menu, text="📃Manage Flashcards", command=lambda: show_frame(flashcard_list), **button_style).pack(pady=10)
tk.Button(flashcard_menu, text="🔙 Back to Menu", command=lambda: show_frame(main_menu), **button_style).pack(pady=30)

# flash card practice
def load_flashcard_sets():
    for widget in flashcard_practice.winfo_children():
        widget.destroy()

    tk.Label(flashcard_practice, text="Select a set to practice", font=("Arial", 14), bg="#f0f0f0").pack(pady=10)

    # --- Scrollable area ---
    scrollable_frame = create_scrollable_frame(flashcard_practice)

    for set_name in flashcard_sets:
        btn = tk.Button(scrollable_frame, text=set_name[:50] + ("..." if len(set_name) > 50 else ""),
                        command=lambda name=set_name: practice_set(name), **button_style)
        btn.pack(pady=5, padx=75)
        tooltip(btn, set_name)

    # --- Buttons below scroll area ---
    tk.Button(flashcard_practice, text="🔙 Back", command=lambda: show_frame(flashcard_menu), **button_style).pack(pady=30)

def practice_set(set_name):
    global current_cards, current_index, is_showing_answer
    current_cards = flashcard_sets[set_name]
    current_index = 0
    is_showing_answer = False

    for widget in flashcard_practice.winfo_children():
        widget.destroy()

    if not current_cards:
        tk.Label(flashcard_practice, text="This set is empty!", font=("Arial", 14), bg="#f0f0f0").pack(pady=20)
        tk.Button(flashcard_practice, text="🔙 Back", command=load_flashcard_sets, **button_style).pack(pady=10)
        return

    card_label = tk.Label(flashcard_practice, text="", font=("Arial", 16), wraplength=350, bg="#f0f0f0")
    card_label.pack(pady=40)

    def show_card():
        global is_showing_answer
        card = current_cards[current_index]
        if is_showing_answer:
            card_label.config(text=f"A: {card['A']}")
            action_button.config(text="➡️ Next")
        else:
            card_label.config(text=f"Q: {card['Q']}")
            action_button.config(text="👁 Show Answer")

    def next_card():
        global current_index, is_showing_answer
        if is_showing_answer:
            current_index += 1
            if current_index < len(current_cards):
                is_showing_answer = False
                show_card()
            else:
                card_label.config(text="🎉 Done! You've reached the end.")
                action_button.config(text="🔁 Restart", command=lambda: practice_set(set_name))
        else:
            is_showing_answer = True
            show_card()

    action_button = tk.Button(flashcard_practice, text="", command=next_card, **button_style)
    action_button.pack(pady=20)

    tk.Button(flashcard_practice, text="🔙 Back", command=load_flashcard_sets, **button_style).pack(pady=30)

    show_card()
# flash card management page
def refresh_set_list():
    for widget in flashcard_list.winfo_children():
        widget.destroy()

    # --- Scrollable area ---
    tk.Label(flashcard_list, text="Manage Flashcard Sets", font=("Arial", 14), bg="#f0f0f0").pack(pady=5)
    scrollable_frame = create_scrollable_frame(flashcard_list)


    # --- Content inside the scrollable area ---


    for set_name in flashcard_sets:
        frame = tk.Frame(scrollable_frame, bg="#f0f0f0")
        frame.pack(pady=15, padx=70, anchor="w")
        label = tk.Label(frame, text=set_name[:15] + ("..." if len(set_name) > 15 else ""), font=("Arial", 12),
                         width=15, anchor="w")
        label.pack(side="left")
        tooltip(label, set_name)
        tk.Button(frame, text="✏️ Edit", command=lambda name=set_name: edit_set(name)).pack(side="left", padx=5)
        tk.Button(frame, text="🗑 Delete", command=lambda name=set_name: delete_set(name)).pack(side="left", padx=5)

    # --- Static buttons below scroll area ---
    bottom_frame = tk.Frame(flashcard_list, bg="#f0f0f0")
    bottom_frame.pack(pady=5)

    tk.Button(bottom_frame, text="➕ Add New Set", command=add_set, **button_style).pack(pady=5)
    tk.Button(bottom_frame, text="🔙 Back to flashcards", command=lambda: show_frame(flashcard_menu), **button_style).pack(pady=5)

def add_set():
    name = simpledialog.askstring("New Set", "Enter the name of the new set:")
    if name and name.strip():  # only accept non-empty, non-whitespace names
        name = name.strip()
        if name not in flashcard_sets:
            flashcard_sets[name] = []
            save_flashcards()
            refresh_set_list()
            load_flashcard_sets()
    else:
        messagebox.showerror("Invalid Name", "Set name cannot be empty.")

def delete_set(name):
    if messagebox.askyesno("Confirm Delete", f"Delete set '{name}'?"):
        del flashcard_sets[name]
        save_flashcards()
        refresh_set_list()


def edit_set(set_name):
        def refresh_cards():
            for widget in edit_set_frame.winfo_children():
                widget.destroy()

            tk.Label(edit_set_frame, text=f"Editing Set: {set_name}", font=("Arial", 14), bg="#f0f0f0").pack(pady=10)

            scrollable_frame = create_scrollable_frame(edit_set_frame)

            for i, card in enumerate(flashcard_sets[set_name]):
                frame = tk.Frame(scrollable_frame, bg="#f0f0f0")
                frame.pack(pady=5)

                q = card["Q"]
                a = card["A"]

                tk.Label(frame, text=f"Q: {q}, A: {a}", width=20, anchor="w").pack(side="left", padx=15)
                tk.Button(frame, text="✏️", command=lambda i=i: edit_card(i)).pack(side="left", padx=2)
                tk.Button(frame, text="🗑", command=lambda i=i: delete_card(i)).pack(side="left", padx=2)

            tk.Button(edit_set_frame, text="➕ Add Card", command=add_card, **button_style).pack(pady=10)
            tk.Button(edit_set_frame, text="🔙 Back", command=lambda: show_frame(flashcard_list), **button_style).pack(
                pady=10)

        def add_card():
            q = simpledialog.askstring("New Flashcard", "Enter the question:")
            if not q or not q.strip():
                messagebox.showerror("Invalid Input", "Question cannot be empty.")
                return
            q = q.strip()

            a = simpledialog.askstring("New Flashcard", "Enter the answer:")
            if a is None or not a.strip():
                messagebox.showerror("Invalid Input", "Answer cannot be empty.")
                return
            a = a.strip()

            flashcard_sets[set_name].append({"Q": q, "A": a})
            save_flashcards()
            refresh_cards()

        def edit_card(index):
            current = flashcard_sets[set_name][index]
            new_q = simpledialog.askstring("Edit Question", "Edit the question:", initialvalue=current["Q"])
            if new_q is None or not new_q.strip():
                messagebox.showerror("Invalid Input", "Question cannot be empty.")
                return
            new_q = new_q.strip()

            new_a = simpledialog.askstring("Edit Answer", "Edit the answer:", initialvalue=current["A"])
            if new_a is None or not new_a.strip():
                messagebox.showerror("Invalid Input", "Answer cannot be empty.")
                return
            new_a = new_a.strip()

            flashcard_sets[set_name][index] = {"Q": new_q, "A": new_a}
            save_flashcards()
            refresh_cards()

        def delete_card(index):
            if messagebox.askyesno("Delete", "Delete this flashcard?"):
                del flashcard_sets[set_name][index]
                refresh_cards()

        show_frame(edit_set_frame)
        refresh_cards()


tk.Button(flashcard_list, text="➕ Add New Set", command=add_set, **button_style).pack(pady=10)
tk.Button(flashcard_list, text="🔙 Back to flashcards", command=lambda: show_frame(flashcard_menu), **button_style).pack(pady=30)




# --------- Navigation Logic ---------

show_frame(main_menu)
load_flashcard_sets()
save_flashcards()
refresh_set_list()


window.mainloop()