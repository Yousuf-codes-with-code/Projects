import random
from enum import nonmember

options =("rock","paper","scissor")

playing =True

while playing:

    player = None
    computer = random.choice(options)

    while player not in options:
        player = input("Enter your choice (rock, paper, or scissors): ")


    print(f"player choice: {player}")
    print(f"computer's choice: {computer}")


    if computer == player:
        print("It's a tie!")
    elif player == "rock" and computer == "scissor":
        print("you win!")
    elif player == "rock" and computer == "paper":
        print("you lose!")
    elif player == "paper" and computer == "scissor":
        print("you lose!")
    elif player == "paper" and computer == "rock":
        print("you win!")
    elif player == "scissor" and computer == "rock":
        print("you lose!")
    elif player == "scissor" and computer == "paper":
        print("you win!")
    else:
        print("you lose!")

